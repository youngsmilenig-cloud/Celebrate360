# Celebrate360 v2.1 — APK build from an Android phone

This package is prepared for a cloud build. The repository contains a GitHub Actions workflow that generates the standard Android wrapper, gets Flutter dependencies, analyzes the project, and builds a release APK.

## Phone-only route

1. Create/sign in to a GitHub account in Chrome.
2. Create a new repository named `celebrate360`.
3. Upload the contents of this project ZIP to the repository (extract the ZIP first).
4. Open **Actions** → **Build Celebrate360 APK** → **Run workflow**.
5. Wait for the workflow to finish.
6. Open the completed workflow run and download the **Celebrate360-APK** artifact.
7. Extract the artifact and install `app-release.apk` on the Android phone.

## Important

- The first build downloads Flutter and Android dependencies, so it can take several minutes.
- Android may ask you to allow installation from the browser/file manager. Only enable that for the app you trust, then disable it again afterward.
- This workflow is for building/testing. It does not silently send WhatsApp or SMS messages.
- For a Play Store release, use a properly signed Android App Bundle (`flutter build appbundle`) and keep the signing key private.
