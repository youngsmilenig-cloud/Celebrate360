# Celebrate360 v1.7 — Smart Dashboard & Greeting Automation Prep

Added:
- Smart dashboard cards for Today, Next 7 Days and Next 30 Days.
- Upcoming celebration list with days-until countdown.
- Today's celebration highlight.
- Customizable greeting templates saved locally with SharedPreferences.
- Communication Center now reads saved templates and replaces `{name}` automatically.
- Dedicated Greeting Templates screen.
- One-tap route from dashboard to Communication Center.

Important:
- This is a Flutter source package, not a compiled APK.
- Automatic Android notification scheduling remains a separate integration step and depends on a complete Android/Gradle project and device testing.
