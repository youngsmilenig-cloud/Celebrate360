# Celebrate360 v1.8 — Smart Automation Engine

Adds an automation layer for birthday/anniversary reminders.

## Included
- 7-day, 3-day, 1-day and same-day reminder schedule.
- Default reminder time: 8:00 AM.
- Device timezone initialization via flutter_timezone.
- Android notification channel.
- Stable notification IDs so schedules can be rebuilt.
- Reschedule method that clears old reminders before rebuilding from current member data.

## Important
This is source code, not a compiled APK. The repository still needs the standard Flutter Android project/Gradle scaffolding and must be built/tested on a Flutter-capable environment. Android notification scheduling also depends on device/OEM background behavior and notification permissions.
