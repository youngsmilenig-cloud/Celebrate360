# Celebrate360 v1.6 — Communication Center

Added a member communication center with:
- Birthday, anniversary, Christmas and New Year greeting templates.
- Member search and phone display.
- Prepared message preview.
- User-triggered WhatsApp launch.
- User-triggered SMS launch.
- Copy greeting to clipboard.
- Call member button.
- Nigerian phone normalization for WhatsApp (080... -> 23480...).

Important: this version prepares and opens messages; it does not silently send WhatsApp/SMS in the background.

Dependency: url_launcher ^6.3.2.

This is source code, not a compiled APK. A full Flutter/Android build environment is still required to produce and test the APK.
