# Celebrate360 v2.1 — APK Ready

This milestone focuses on making the source project ready for a cloud Android build without requiring Flutter or Android Studio on the user's phone.

Added:
- Version bumped to 2.1.0+21.
- GitHub Actions workflow for a release APK.
- Automatic generation of the standard Android project wrapper with `flutter create . --platforms=android`.
- Flutter dependency installation.
- Static analysis before APK compilation.
- Release APK artifact upload.
- Phone-only build instructions.

Note: The current ChatGPT build environment still does not compile the APK itself. The APK is produced by the configured cloud workflow.
