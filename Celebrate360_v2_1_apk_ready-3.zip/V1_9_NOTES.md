# Celebrate360 v1.9 — Member Care + Automation Control Center

- Central automation screen for turning reminders on/off.
- Reminder time can be changed and scheduled reminders refreshed immediately.
- Manual refresh and test notification controls.
- Dashboard now links directly to Automation Control Center.
- App startup reads church settings and schedules/cancels reminders accordingly.
- Uses existing 7/3/1/0-day birthday and anniversary automation.
- Messages remain user-triggered through WhatsApp/SMS; no silent message sending.

Source package only; Flutter/Android build tooling is not available in this environment, so APK compilation was not performed here.
