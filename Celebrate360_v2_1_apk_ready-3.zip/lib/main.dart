import 'package:flutter/material.dart';
import 'models/member.dart';
import 'services/member_data_service.dart';
import 'screens/dashboard_screen.dart';
import 'services/notification_service.dart';
import 'services/settings_store.dart';
import 'services/automation_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await NotificationService.initialize();
  runApp(const Celebrate360App());
}

class Celebrate360App extends StatelessWidget {
  const Celebrate360App({super.key});
  @override Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Celebrate360',
    theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
    home: const Home(),
  );
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override State<Home> createState() => _HomeState();
}
class _HomeState extends State<Home> {
  late Future<List<Member>> future;
  @override void initState() { super.initState(); future = MemberDataService().loadMembers(); }
  Future<void> _scheduleIfEnabled(List<Member> members) async {
    final settings = await SettingsStore().load();
    if (settings.remindersEnabled) {
      await AutomationService.reschedule(members, reminderHour: settings.reminderHour);
    } else {
      await AutomationService.cancel();
    }
  }
  @override Widget build(BuildContext context) => FutureBuilder<List<Member>>(
    future: future,
    builder: (context, snap) {
      if (!snap.hasData) return const Scaffold(body: Center(child: CircularProgressIndicator()));
      final members = snap.data!;
      _scheduleIfEnabled(members);
      return DashboardScreen(members: members);
    },
  );
}
