import 'package:shared_preferences/shared_preferences.dart';

class GreetingTemplateStore {
  static const defaults = {
    'Birthday': 'Dear {name}, happy birthday! We thank God for your life and pray that this new year brings you greater grace, divine favour, peace and fulfilment. God bless you richly!',
    'Anniversary': 'Dear {name}, congratulations on your anniversary! May God continue to strengthen your home with love, peace, grace and lasting joy. From your church family. God bless you!',
    'Christmas': 'Dear {name}, Merry Christmas! May the joy, peace and love of Christ fill your heart and home. We celebrate God\'s goodness with you. God bless you!',
    'New Year': 'Dear {name}, Happy New Year! May this year bring you divine favour, fresh strength, open doors and abundant testimonies. We celebrate you and pray for you. God bless you!',
  };

  Future<String> get(String type) async {
    final p = await SharedPreferences.getInstance();
    return p.getString('greeting_$type') ?? defaults[type]!;
  }

  Future<void> save(String type, String text) async {
    final p = await SharedPreferences.getInstance();
    await p.setString('greeting_$type', text);
  }
}
