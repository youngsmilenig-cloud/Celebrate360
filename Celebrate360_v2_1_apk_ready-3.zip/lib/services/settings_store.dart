import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/church_settings.dart';

class SettingsStore {
  static const _key = 'celebrate360_church_settings';

  Future<ChurchSettings> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    return raw == null
      ? ChurchSettings.defaults()
      : ChurchSettings.fromJson(jsonDecode(raw));
  }

  Future<void> save(ChurchSettings settings) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(settings.toJson()));
  }
}
