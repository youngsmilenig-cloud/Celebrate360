import 'dart:convert';
import 'package:flutter/services.dart';
import '../models/member.dart';

class MemberDataService {
  Future<List<Member>> loadMembers() async {
    final raw = await rootBundle.loadString('assets/members.json');
    final list = jsonDecode(raw) as List;
    return list.map((e) => Member.fromJson(e)).toList();
  }
}
