import 'package:url_launcher/url_launcher.dart';

class CommunicationService {
  static String normalizeNigeriaPhone(String phone) {
    var p = phone.replaceAll(RegExp(r'[^0-9+]'), '');
    if (p.startsWith('+')) p = p.substring(1);
    if (p.startsWith('234')) return p;
    if (p.startsWith('0')) return '234${p.substring(1)}';
    return p;
  }

  static Future<bool> whatsapp(String phone, String message) async {
    final number = normalizeNigeriaPhone(phone);
    final uri = Uri.https('wa.me', '/$number', {'text': message});
    return launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  static Future<bool> sms(String phone, String message) async {
    final uri = Uri(scheme: 'sms', path: phone, queryParameters: {'body': message});
    return launchUrl(uri);
  }

  static Future<bool> call(String phone) async => launchUrl(Uri(scheme: 'tel', path: phone));
}
