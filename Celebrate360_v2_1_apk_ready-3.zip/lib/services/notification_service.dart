import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tz;
import 'package:timezone/timezone.dart' as tz;
import 'package:flutter_timezone/flutter_timezone.dart';

class NotificationService {
  static final _plugin = FlutterLocalNotificationsPlugin();
  static const _channelId = 'celebrate360_celebrations';
  static const _channelName = 'Celebrate360 Celebrations';
  static bool _ready = false;

  static Future<void> initialize() async {
    if (_ready) return;
    tz.initializeTimeZones();
    final timezone = await FlutterTimezone.getLocalTimezone();
    tz.setLocalLocation(tz.getLocation(timezone.name));
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const settings = InitializationSettings(android: android);
    await _plugin.initialize(settings);
    const channel = AndroidNotificationChannel(
      _channelId,
      _channelName,
      description: 'Birthday and anniversary reminders',
      importance: Importance.high,
    );
    await _plugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);
    _ready = true;
  }

  static Future<void> schedule(int id, String title, String body, DateTime date) async {
    await initialize();
    final scheduled = tz.TZDateTime.from(date, tz.local);
    if (scheduled.isBefore(tz.TZDateTime.now(tz.local))) return;
    const details = NotificationDetails(
      android: AndroidNotificationDetails(
        _channelId,
        _channelName,
        channelDescription: 'Birthday and anniversary reminders',
        importance: Importance.high,
        priority: Priority.high,
      ),
    );
    await _plugin.zonedSchedule(
      id,
      title,
      body,
      scheduled,
      details,
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      payload: 'celebration',
    );
  }

  static Future<void> showNow(int id, String title, String body) async {
    await initialize();
    const details = NotificationDetails(android: AndroidNotificationDetails(_channelId, _channelName, channelDescription: 'Birthday and anniversary reminders', importance: Importance.high, priority: Priority.high));
    await _plugin.show(id, title, body, details, payload: 'test');
  }

  static Future<void> cancelAll() async {
    await initialize();
    await _plugin.cancelAll();
  }
}
