import '../models/member.dart';

class DashboardService {
  static DateTime? monthDay(String raw, int year) {
    final m = RegExp(r'(\d{1,2}).*?(JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)', caseSensitive:false).firstMatch(raw);
    if (m == null) return null;
    const months = {'JAN':1,'FEB':2,'MAR':3,'APR':4,'MAY':5,'JUN':6,'JUL':7,'AUG':8,'SEP':9,'OCT':10,'NOV':11,'DEC':12};
    return DateTime(year, months[m.group(2)!.toUpperCase()]!, int.parse(m.group(1)!));
  }

  static List<Member> today(List<Member> members, DateTime now) => members.where((x) {
    final d = monthDay(x.dob, now.year);
    final a = monthDay(x.anniversary, now.year);
    return (d != null && d.month == now.month && d.day == now.day) ||
           (a != null && a.month == now.month && a.day == now.day);
  }).toList();

  static int upcoming(List<Member> members, DateTime now, int days) {
    return members.where((x) {
      for (final raw in [x.dob, x.anniversary]) {
        final d = monthDay(raw, now.year);
        if (d != null) {
          var candidate = d;
          if (candidate.isBefore(DateTime(now.year, now.month, now.day))) {
            candidate = DateTime(now.year + 1, d.month, d.day);
          }
          final delta = candidate.difference(DateTime(now.year, now.month, now.day)).inDays;
          if (delta > 0 && delta <= days) return true;
        }
      }
      return false;
    }).length;
  }
}
