import '../models/member.dart';
import 'celebration_service.dart';
import 'notification_service.dart';

class AutomationService {
  static const reminderOffsets = [7, 3, 1, 0];

  static Future<void> reschedule(List<Member> members, {DateTime? now, int reminderHour = 8}) async {
    final today = now ?? DateTime.now();
    await NotificationService.cancelAll();
    final items = CelebrationService.upcoming(members, today, days: 370);
    for (final item in items) {
      for (final offset in reminderOffsets) {
        final reminderDate = item.date.subtract(Duration(days: offset));
        final at = DateTime(reminderDate.year, reminderDate.month, reminderDate.day, reminderHour);
        if (!at.isAfter(today)) continue;
        final id = _id(item.member.id, item.type, item.date, offset);
        final label = offset == 0 ? 'Today' : '$offset days left';
        await NotificationService.schedule(
          id,
          '${item.type}: ${item.member.name}',
          '${item.member.name} has a ${item.type.toLowerCase()} today in $label. Open Celebrate360 to send a greeting.',
          at,
        );
      }
    }
  }

  static Future<void> cancel() async => NotificationService.cancelAll();

  static Future<void> testPreview() async {
    await NotificationService.showNow(987654, 'Celebrate360 Test', 'Notifications are working.');
  }

  static int _id(String memberId, String type, DateTime date, int offset) {
    final raw = '$memberId|$type|${date.year}-${date.month}-${date.day}|$offset';
    var hash = 0;
    for (final c in raw.codeUnits) {
      hash = (hash * 31 + c) & 0x7fffffff;
    }
    return hash;
  }
}
