import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/member.dart';

class LocalMemberStore {
  static const _key = 'celebrate360_members';

  Future<List<Member>> load(List<Member> seed) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null) return seed;
    final list = jsonDecode(raw) as List;
    return list.map((e) => Member.fromJson(e)).toList();
  }

  Future<void> save(List<Member> members) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(members.map((m) => {
      'id': m.id, 'name': m.name, 'dob': m.dob, 'phone': m.phone,
      'anniversary': m.anniversary
    }).toList()));
  }

  Future<void> clear() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_key);
  }
}
