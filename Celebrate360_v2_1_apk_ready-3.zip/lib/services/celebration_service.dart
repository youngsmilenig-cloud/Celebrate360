import '../models/member.dart';
import 'dashboard_service.dart';

class CelebrationItem {
  final Member member;
  final String type;
  final DateTime date;
  final int daysUntil;
  CelebrationItem({required this.member, required this.type, required this.date, required this.daysUntil});
}

class CelebrationService {
  static List<CelebrationItem> upcoming(List<Member> members, DateTime now, {int days = 30}) {
    final start = DateTime(now.year, now.month, now.day);
    final items = <CelebrationItem>[];
    for (final m in members) {
      for (final pair in [('Birthday', m.dob), ('Anniversary', m.anniversary)]) {
        final d = DashboardService.monthDay(pair.$2, now.year);
        if (d == null) continue;
        var candidate = DateTime(now.year, d.month, d.day);
        if (candidate.isBefore(start)) candidate = DateTime(now.year + 1, d.month, d.day);
        final delta = candidate.difference(start).inDays;
        if (delta >= 0 && delta <= days) {
          items.add(CelebrationItem(member: m, type: pair.$1, date: candidate, daysUntil: delta));
        }
      }
    }
    items.sort((a,b) => a.date.compareTo(b.date));
    return items;
  }
}
