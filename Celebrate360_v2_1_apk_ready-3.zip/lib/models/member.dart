class Member {
  final String id, name, dob, phone, anniversary;
  Member({required this.id, required this.name, required this.dob, required this.phone, required this.anniversary});
  factory Member.fromJson(Map<String,dynamic> j) => Member(
    id: j['id'] ?? '', name: j['name'] ?? '', dob: j['dob'] ?? '',
    phone: j['phone'] ?? '', anniversary: j['anniversary'] ?? '');
}
