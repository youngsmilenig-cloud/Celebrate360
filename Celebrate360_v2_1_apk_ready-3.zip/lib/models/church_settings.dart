class ChurchSettings {
  final String churchName;
  final String pastorName;
  final String pastorInfo;
  final String maintenancePhone;
  final bool remindersEnabled;
  final int reminderHour;

  const ChurchSettings({
    required this.churchName,
    required this.pastorName,
    required this.pastorInfo,
    required this.maintenancePhone,
    required this.remindersEnabled,
    required this.reminderHour,
  });

  factory ChurchSettings.defaults() => const ChurchSettings(
    churchName: "Dunamis International Gospel Centre DABI/Bako",
    pastorName: "Pastor",
    pastorInfo: "",
    maintenancePhone: "07081999330",
    remindersEnabled: true,
    reminderHour: 8,
  );

  ChurchSettings copyWith({String? churchName, String? pastorName, String? pastorInfo, String? maintenancePhone, bool? remindersEnabled, int? reminderHour}) => ChurchSettings(
    churchName: churchName ?? this.churchName, pastorName: pastorName ?? this.pastorName, pastorInfo: pastorInfo ?? this.pastorInfo, maintenancePhone: maintenancePhone ?? this.maintenancePhone, remindersEnabled: remindersEnabled ?? this.remindersEnabled, reminderHour: reminderHour ?? this.reminderHour);

  Map<String,dynamic> toJson() => {
    "churchName": churchName, "pastorName": pastorName, "pastorInfo": pastorInfo,
    "maintenancePhone": maintenancePhone, "remindersEnabled": remindersEnabled,
    "reminderHour": reminderHour,
  };

  factory ChurchSettings.fromJson(Map<String,dynamic> j) => ChurchSettings(
    churchName: j["churchName"] ?? "",
    pastorName: j["pastorName"] ?? "",
    pastorInfo: j["pastorInfo"] ?? "",
    maintenancePhone: j["maintenancePhone"] ?? "",
    remindersEnabled: j["remindersEnabled"] ?? true,
    reminderHour: j["reminderHour"] ?? 8,
  );
}
