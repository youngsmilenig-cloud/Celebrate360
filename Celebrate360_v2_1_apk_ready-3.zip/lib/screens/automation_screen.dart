import 'package:flutter/material.dart';
import '../models/member.dart';
import '../services/automation_service.dart';
import '../services/settings_store.dart';

class AutomationScreen extends StatefulWidget {
  final List<Member> members;
  const AutomationScreen({super.key, required this.members});
  @override State<AutomationScreen> createState() => _AutomationScreenState();
}

class _AutomationScreenState extends State<AutomationScreen> {
  bool enabled = true;
  int hour = 8;
  bool busy = false;
  String status = 'Checking automation settings…';

  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final s = await SettingsStore().load();
    if (!mounted) return;
    setState(() { enabled = s.remindersEnabled; hour = s.reminderHour; status = enabled ? 'Automation is ON' : 'Automation is OFF'; });
  }

  Future<void> _apply(bool turnOn) async {
    setState(() { busy = true; });
    final s = await SettingsStore().load();
    final updated = s.copyWith(remindersEnabled: turnOn, reminderHour: hour);
    await SettingsStore().save(updated);
    if (turnOn) {
      await AutomationService.reschedule(widget.members, reminderHour: hour);
    } else {
      await AutomationService.cancel();
    }
    if (!mounted) return;
    setState(() { enabled = turnOn; busy = false; status = turnOn ? 'Automation is ON — reminders scheduled.' : 'Automation is OFF — scheduled reminders cancelled.'; });
  }

  Future<void> _reschedule() async {
    setState(() => busy = true);
    await AutomationService.reschedule(widget.members, reminderHour: hour);
    if (!mounted) return;
    setState(() { busy = false; status = 'Reminders refreshed successfully.'; });
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Celebration reminders refreshed')));
  }

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Automation Control Center')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Icon(enabled ? Icons.notifications_active : Icons.notifications_off, size: 32), const SizedBox(width: 12), Expanded(child: Text(status, style: Theme.of(context).textTheme.titleMedium))]),
        const SizedBox(height: 12),
        SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Automatic celebration reminders'), subtitle: const Text('7, 3, 1 and 0-day reminders'), value: enabled, onChanged: busy ? null : _apply),
      ]))),
      const SizedBox(height: 12),
      Card(child: ListTile(leading: const Icon(Icons.schedule), title: const Text('Reminder time'), subtitle: Text('${hour.toString().padLeft(2,'0')}:00'), trailing: DropdownButton<int>(value: hour, items: List.generate(24, (i) => DropdownMenuItem(value:i, child:Text('${i.toString().padLeft(2,'0')}:00'))), onChanged: busy ? null : (v) async { if (v == null) return; setState(() => hour=v); if (enabled) await _reschedule(); }))),
      const SizedBox(height: 12),
      FilledButton.icon(onPressed: busy ? null : _reschedule, icon: busy ? const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)) : const Icon(Icons.refresh), label: const Text('Refresh Scheduled Reminders')),
      const SizedBox(height: 8),
      OutlinedButton.icon(onPressed: busy || !enabled ? null : () async { await AutomationService.testPreview(); if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Test notification requested'))); }, icon: const Icon(Icons.notifications), label: const Text('Test Notification')),
      const SizedBox(height: 20),
      Text('How it works', style: Theme.of(context).textTheme.titleLarge),
      const SizedBox(height: 8),
      const ListTile(leading: CircleAvatar(child: Text('7')), title: Text('7 days before'), subtitle: Text('Early preparation reminder')),
      const ListTile(leading: CircleAvatar(child: Text('3')), title: Text('3 days before'), subtitle: Text('Follow-up reminder')),
      const ListTile(leading: CircleAvatar(child: Text('1')), title: Text('1 day before'), subtitle: Text('Final preparation reminder')),
      const ListTile(leading: CircleAvatar(child: Text('0')), title: Text('Celebration day'), subtitle: Text('Today — open Celebrate360 and send a greeting')),
      const SizedBox(height: 12),
      const Text('Note: Android may restrict background delivery for some apps/devices. Celebrate360 schedules local notifications; it does not silently send WhatsApp or SMS messages.'),
    ]),
  );
}
