import 'package:flutter/material.dart';
import '../services/greeting_template_store.dart';

class TemplatesScreen extends StatefulWidget {
  const TemplatesScreen({super.key});
  @override State<TemplatesScreen> createState() => _TemplatesScreenState();
}
class _TemplatesScreenState extends State<TemplatesScreen> {
  final store = GreetingTemplateStore();
  String type = 'Birthday';
  final controller = TextEditingController();
  bool loading = true;

  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async { controller.text = await store.get(type); if (mounted) setState(() => loading = false); }
  Future<void> _change(String v) async { setState(() { type = v; loading = true; }); controller.text = await store.get(type); if (mounted) setState(() => loading = false); }
  Future<void> _save() async { await store.save(type, controller.text.trim()); if (!mounted) return; ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Greeting template saved.'))); }

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Greeting Templates')),
    body: loading ? const Center(child: CircularProgressIndicator()) : ListView(padding: const EdgeInsets.all(16), children: [
      const Text('Customize messages used by the Communication Center.', style: TextStyle(fontSize: 16)),
      const SizedBox(height: 14),
      DropdownButtonFormField<String>(value: type, decoration: const InputDecoration(labelText: 'Template', border: OutlineInputBorder()), items: GreetingTemplateStore.defaults.keys.map((x) => DropdownMenuItem(value: x, child: Text(x))).toList(), onChanged: (v) => _change(v!)),
      const SizedBox(height: 14),
      TextField(controller: controller, minLines: 6, maxLines: 10, decoration: const InputDecoration(labelText: 'Message', alignLabelWithHint: true, border: OutlineInputBorder(), helperText: 'Use {name} where the member\'s name should appear.')),
      const SizedBox(height: 14),
      FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save), label: const Text('Save Template')),
    ]),
  );
}
