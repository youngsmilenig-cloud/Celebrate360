import 'package:flutter/material.dart';
import '../models/member.dart';
import '../services/local_member_store.dart';
import '../services/dashboard_service.dart';
import '../services/celebration_service.dart';
import 'settings_screen.dart';
import 'communication_screen.dart';
import 'templates_screen.dart';
import 'automation_screen.dart';
import 'member_care_center_screen.dart';

class DashboardScreen extends StatefulWidget {
  final List<Member> members;
  const DashboardScreen({super.key, required this.members});
  @override State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  late List<Member> members;
  final store = LocalMemberStore();
  String query = '';
  @override void initState() { super.initState(); members = [...widget.members]; _restore(); }
  Future<void> _restore() async { final saved = await store.load(members); if (mounted) setState(() => members = saved); }
  Future<void> _edit([Member? old]) async {
    final name=TextEditingController(text:old?.name??''), phone=TextEditingController(text:old?.phone??''), dob=TextEditingController(text:old?.dob??''), ann=TextEditingController(text:old?.anniversary??'');
    final result=await showDialog<Member>(context:context,builder:(_)=>AlertDialog(title:Text(old==null?'Add Member':'Edit Member'),content:SingleChildScrollView(child:Column(children:[TextField(controller:name,decoration:const InputDecoration(labelText:'Full name')),TextField(controller:phone,decoration:const InputDecoration(labelText:'Phone number')),TextField(controller:dob,decoration:const InputDecoration(labelText:'Date of birth')),TextField(controller:ann,decoration:const InputDecoration(labelText:'Anniversary'))])),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Cancel')),FilledButton(onPressed:(){if(name.text.trim().isEmpty)return;Navigator.pop(context,Member(id:old?.id??'DABI-${DateTime.now().millisecondsSinceEpoch}',name:name.text.trim(),phone:phone.text.trim(),dob:dob.text.trim(),anniversary:ann.text.trim()));},child:const Text('Save'))]));
    if(result==null)return; setState((){final i=members.indexWhere((m)=>m.id==result.id);if(i>=0)members[i]=result;else members.add(result);}); await store.save(members);
  }
  Future<void> _delete(Member m) async { setState(()=>members.removeWhere((x)=>x.id==m.id)); await store.save(members); }

  @override Widget build(BuildContext context) {
    final now=DateTime.now();
    final today=DashboardService.today(members,now);
    final next7=CelebrationService.upcoming(members,now,days:7);
    final next30=CelebrationService.upcoming(members,now,days:30);
    final shown=members.where((m)=>m.name.toLowerCase().contains(query.toLowerCase())||m.phone.contains(query)).toList();
    return Scaffold(appBar:AppBar(title:const Text('Celebrate360'),actions:[IconButton(icon:const Icon(Icons.settings),onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const SettingsScreen())))]),floatingActionButton:FloatingActionButton.extended(onPressed:()=>_edit(),icon:const Icon(Icons.person_add),label:const Text('Add Member')),body:ListView(padding:const EdgeInsets.all(16),children:[
      Text('Member Care Dashboard',style:Theme.of(context).textTheme.headlineSmall), const SizedBox(height:4), Text('${members.length} members saved on this phone'), const SizedBox(height:16),
      Row(children:[Expanded(child:_stat('Today',today.length,Icons.today)),const SizedBox(width:8),Expanded(child:_stat('7 Days',next7.length,Icons.event)),const SizedBox(width:8),Expanded(child:_stat('30 Days',next30.length,Icons.date_range))]), const SizedBox(height:16),
      FilledButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>CommunicationScreen(members:members))),icon:const Icon(Icons.send),label:const Text('Communication Center')),
      const SizedBox(height:8), OutlinedButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>MemberCareCenterScreen(members:members))),icon:const Icon(Icons.volunteer_activism),label:const Text('Member Care Center')),
      const SizedBox(height:8), OutlinedButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const TemplatesScreen())),icon:const Icon(Icons.edit_note),label:const Text('Greeting Templates')),
      const SizedBox(height:8), OutlinedButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>AutomationScreen(members:members))),icon:const Icon(Icons.auto_awesome),label:const Text('Automation Control Center')),
      const SizedBox(height:18),
      if(today.isNotEmpty) ...[Text('🎉 Celebrating Today',style:Theme.of(context).textTheme.titleLarge),const SizedBox(height:6),...today.map((m)=>Card(child:ListTile(leading:const CircleAvatar(child:Icon(Icons.celebration)),title:Text(m.name),subtitle:Text('${m.dob.isNotEmpty?'Birthday':'Celebration'} • ${m.phone}'),trailing:IconButton(icon:const Icon(Icons.send),onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>CommunicationScreen(members:members))))))),const SizedBox(height:10)],
      Text('Upcoming — Next 30 Days',style:Theme.of(context).textTheme.titleLarge), const SizedBox(height:6),
      ...next30.take(10).map((x)=>ListTile(leading:CircleAvatar(child:Text(x.daysUntil==0?'0':x.daysUntil.toString())),title:Text(x.member.name),subtitle:Text('${x.type} • ${x.date.day}/${x.date.month}/${x.date.year}'),trailing:Text(x.daysUntil==0?'Today':'in ${x.daysUntil}d'))),
      const Divider(height:28), TextField(onChanged:(v)=>setState(()=>query=v),decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'Search name or phone',border:OutlineInputBorder())), const SizedBox(height:12),
      ...shown.map((m)=>Card(child:ListTile(leading:const CircleAvatar(child:Icon(Icons.person)),title:Text(m.name),subtitle:Text('${m.phone}\nDOB: ${m.dob} • Anniversary: ${m.anniversary}'),isThreeLine:true,trailing:PopupMenuButton<String>(onSelected:(v)=>v=='edit'?_edit(m):_delete(m),itemBuilder:(_)=>const[PopupMenuItem(value:'edit',child:Text('Edit')),PopupMenuItem(value:'delete',child:Text('Delete'))])))),
    ]));
  }
  Widget _stat(String label,int value,IconData icon)=>Card(child:Padding(padding:const EdgeInsets.symmetric(vertical:12,horizontal:8),child:Column(children:[Icon(icon),const SizedBox(height:4),Text('$value',style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold)),Text(label)])));
}
