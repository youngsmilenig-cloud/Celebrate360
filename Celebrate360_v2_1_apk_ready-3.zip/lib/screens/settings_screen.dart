import 'package:flutter/material.dart';
import '../models/church_settings.dart';
import '../services/settings_store.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final store = SettingsStore();
  final church = TextEditingController();
  final pastor = TextEditingController();
  final info = TextEditingController();
  final phone = TextEditingController();
  bool reminders = true;
  int hour = 8;

  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final s = await store.load();
    church.text=s.churchName; pastor.text=s.pastorName; info.text=s.pastorInfo;
    phone.text=s.maintenancePhone; reminders=s.remindersEnabled; hour=s.reminderHour;
    if (mounted) setState(() {});
  }
  Future<void> _save() async {
    await store.save(ChurchSettings(
      churchName: church.text.trim(), pastorName: pastor.text.trim(),
      pastorInfo: info.text.trim(), maintenancePhone: phone.text.trim(),
      remindersEnabled: reminders, reminderHour: hour));
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Church settings saved')));
  }

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Church Settings')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      Text('Church Information', style: Theme.of(context).textTheme.titleLarge),
      const SizedBox(height: 12),
      TextField(controller: church, decoration: const InputDecoration(labelText:'Church name', border:OutlineInputBorder())),
      const SizedBox(height: 10),
      TextField(controller: pastor, decoration: const InputDecoration(labelText:"Pastor's name", border:OutlineInputBorder())),
      const SizedBox(height: 10),
      TextField(controller: info, maxLines:3, decoration: const InputDecoration(labelText:"Pastor information", border:OutlineInputBorder())),
      const SizedBox(height: 10),
      TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText:'Maintenance/contact phone', border:OutlineInputBorder())),
      const SizedBox(height: 20),
      SwitchListTile(title: const Text('Automatic reminders'), value: reminders, onChanged:(v)=>setState(()=>reminders=v)),
      ListTile(
        title: const Text('Reminder time'),
        subtitle: Text('${hour.toString().padLeft(2,'0')}:00'),
        trailing: DropdownButton<int>(
          value: hour,
          items: List.generate(24,(i)=>DropdownMenuItem(value:i, child:Text('${i.toString().padLeft(2,'0')}:00'))),
          onChanged:(v)=>setState(()=>hour=v ?? 8)),
      ),
      const SizedBox(height: 20),
      FilledButton.icon(onPressed:_save, icon:const Icon(Icons.save), label:const Text('Save Settings')),
    ]),
  );
}
