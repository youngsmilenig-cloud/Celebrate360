import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/member.dart';
import '../services/communication_service.dart';
import '../services/greeting_template_store.dart';

class CommunicationScreen extends StatefulWidget {
  final List<Member> members;
  const CommunicationScreen({super.key, required this.members});
  @override State<CommunicationScreen> createState() => _CommunicationScreenState();
}

class _CommunicationScreenState extends State<CommunicationScreen> {
  Member? selected;
  String type = 'Birthday';
  final search = TextEditingController();
  final templates = GreetingTemplateStore();
  String? customTemplate;
  @override void initState() { super.initState(); _loadTemplate(); }
  Future<void> _loadTemplate() async { customTemplate = await templates.get(type); if (mounted) setState(() {}); }


  String get message {
    final name = selected?.name.isNotEmpty == true ? selected!.name : 'Beloved';
    final template = customTemplate ?? GreetingTemplateStore.defaults[type]!;
    return template.replaceAll('{name}', name);
  }

  List<Member> get filtered {
    final q = search.text.toLowerCase().trim();
    if (q.isEmpty) return widget.members;
    return widget.members.where((m) => m.name.toLowerCase().contains(q) || m.phone.contains(q)).toList();
  }

  Future<void> _action(Future<bool> Function() fn) async {
    if (selected == null || selected!.phone.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Select a member with a phone number first.')));
      return;
    }
    final ok = await fn();
    if (!mounted) return;
    if (!ok) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('No suitable app was found on this phone.')));
  }

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Communication Center')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('Send a prepared greeting', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      const SizedBox(height: 6),
      const Text('Choose a member, preview the message, then open WhatsApp or SMS. Nothing is sent silently.'),
      const SizedBox(height: 16),
      DropdownButtonFormField<String>(value: type, decoration: const InputDecoration(labelText: 'Greeting type', border: OutlineInputBorder()), items: const ['Birthday','Anniversary','Christmas','New Year'].map((x) => DropdownMenuItem(value: x, child: Text(x))).toList(), onChanged: (v) async { type = v!; customTemplate = await templates.get(type); if (mounted) setState(() {}); }),
      const SizedBox(height: 12),
      TextField(controller: search, decoration: const InputDecoration(prefixIcon: Icon(Icons.search), labelText: 'Search member', border: OutlineInputBorder()), onChanged: (_) => setState(() {})),
      const SizedBox(height: 8),
      if (selected == null) ...filtered.take(12).map((m) => ListTile(leading: const CircleAvatar(child: Icon(Icons.person)), title: Text(m.name), subtitle: Text(m.phone.isEmpty ? 'No phone number' : m.phone), onTap: () => setState(() => selected = m))),
      if (selected != null) Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [const CircleAvatar(child: Icon(Icons.person)), const SizedBox(width: 12), Expanded(child: Text(selected!.name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold))), IconButton(onPressed: () => setState(() => selected = null), icon: const Icon(Icons.close))]),
        const SizedBox(height: 12), Text('To: ${selected!.phone}'), const SizedBox(height: 12),
        Container(width: double.infinity, padding: const EdgeInsets.all(14), decoration: BoxDecoration(borderRadius: BorderRadius.circular(12), border: Border.all(color: Theme.of(context).colorScheme.outline)), child: Text(message)),
        const SizedBox(height: 14),
        Wrap(spacing: 8, runSpacing: 8, children: [
          FilledButton.icon(onPressed: () => _action(() => CommunicationService.whatsapp(selected!.phone, message)), icon: const Icon(Icons.chat), label: const Text('WhatsApp')),
          OutlinedButton.icon(onPressed: () => _action(() => CommunicationService.sms(selected!.phone, message)), icon: const Icon(Icons.sms), label: const Text('SMS')),
          OutlinedButton.icon(onPressed: () async { await Clipboard.setData(ClipboardData(text: message)); if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Greeting copied.'))); }, icon: const Icon(Icons.copy), label: const Text('Copy')),
          OutlinedButton.icon(onPressed: () => _action(() => CommunicationService.call(selected!.phone)), icon: const Icon(Icons.call), label: const Text('Call')),
        ])
      ]))),
    ]),
  );
}
