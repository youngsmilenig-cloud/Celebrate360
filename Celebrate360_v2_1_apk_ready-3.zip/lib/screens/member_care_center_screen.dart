import 'package:flutter/material.dart';
import '../models/member.dart';
import '../services/celebration_service.dart';
import 'communication_screen.dart';

class MemberCareCenterScreen extends StatefulWidget {
  final List<Member> members;
  const MemberCareCenterScreen({super.key, required this.members});
  @override State<MemberCareCenterScreen> createState() => _MemberCareCenterScreenState();
}

class _MemberCareCenterScreenState extends State<MemberCareCenterScreen> {
  String filter = 'All';
  String query = '';

  @override Widget build(BuildContext context) {
    final now = DateTime.now();
    final upcoming = CelebrationService.upcoming(widget.members, now, days: 30);
    final today = upcoming.where((x) => x.daysUntil == 0).toList();
    final week = upcoming.where((x) => x.daysUntil <= 7).toList();
    final filtered = upcoming.where((x) {
      final typeOk = filter == 'All' || x.type == filter;
      final q = query.trim().toLowerCase();
      final searchOk = q.isEmpty || x.member.name.toLowerCase().contains(q) || x.member.phone.contains(q);
      return typeOk && searchOk;
    }).toList();

    return Scaffold(
      appBar: AppBar(title: const Text('Member Care Center')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Celebration Overview', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 12),
          Row(children: [Expanded(child: _metric('Today', today.length, Icons.celebration)), const SizedBox(width: 8), Expanded(child: _metric('7 Days', week.length, Icons.event)), const SizedBox(width: 8), Expanded(child: _metric('30 Days', upcoming.length, Icons.date_range))]),
        ]))),
        const SizedBox(height: 12),
        TextField(onChanged: (v) => setState(() => query = v), decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search member or phone', border: OutlineInputBorder())),
        const SizedBox(height: 10),
        SegmentedButton<String>(segments: const [ButtonSegment(value: 'All', label: Text('All')), ButtonSegment(value: 'Birthday', label: Text('Birthdays')), ButtonSegment(value: 'Anniversary', label: Text('Anniversaries'))], selected: {filter}, onSelectionChanged: (v) => setState(() => filter = v.first)),
        const SizedBox(height: 14),
        if (filtered.isEmpty) const Card(child: Padding(padding: EdgeInsets.all(24), child: Center(child: Text('No matching celebrations in the next 30 days.')))),
        ...filtered.map((x) => Card(child: ListTile(
          leading: CircleAvatar(child: Icon(x.type == 'Birthday' ? Icons.cake : Icons.favorite)),
          title: Text(x.member.name),
          subtitle: Text('${x.type} • ${x.member.phone}\n${x.daysUntil == 0 ? 'Celebrating today' : 'In ${x.daysUntil} day(s)'}'),
          isThreeLine: true,
          trailing: PopupMenuButton<String>(onSelected: (v) {
            if (v == 'message') Navigator.push(context, MaterialPageRoute(builder: (_) => CommunicationScreen(members: [x.member])));
          }, itemBuilder: (_) => const [PopupMenuItem(value: 'message', child: Text('Send greeting'))]),
        ))),
      ]),
    );
  }

  Widget _metric(String label, int value, IconData icon) => Card(child: Padding(padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 6), child: Column(children: [Icon(icon), const SizedBox(height: 4), Text('$value', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)), Text(label)])));
}
