# Celebrate360 v2.0

Major integration milestone: Member Care Center.

Added:
- Celebration overview for today, next 7 days and next 30 days.
- Search by member name or phone.
- Birthday/anniversary filters.
- One-tap route to the Communication Center for a selected celebrant.
- Dashboard entry point for the Member Care Center.

This is a Flutter source package. It has not been compiled into an APK in this environment.
