Celebrate360 v1.5 — Church Settings & Admin Controls
- Editable church name
- Editable pastor name and information
- Editable maintenance/contact phone
- Automatic reminder toggle
- Reminder hour selector
- Settings persist locally with SharedPreferences
- Settings accessible from dashboard
- Source package; APK compilation and real Android device testing remain required.
