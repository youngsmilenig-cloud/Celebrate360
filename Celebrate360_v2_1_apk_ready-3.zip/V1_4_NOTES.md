Celebrate360 v1.4 — Member Registration & Local Storage
- Add, edit and delete member records from the Android app UI.
- Search by name or phone.
- Changes persist locally using SharedPreferences.
- Imported workbook remains the seed dataset.
- Source package only; Android APK compilation/device testing still required.
